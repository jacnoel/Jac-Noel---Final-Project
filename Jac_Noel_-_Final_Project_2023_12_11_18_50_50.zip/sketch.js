let colorSelected = 'black';
let penSize = 5;

function setup() {
  createCanvas(800, 600);
  background(255);
}

function draw() {
  if (mouseIsPressed) {
    stroke(colorSelected);
    strokeWeight(penSize);
    line(pmouseX, pmouseY, mouseX, mouseY);
  }
}

function setColor(color) {
  colorSelected = color;
}

function setPenSize(size) {
  penSize = size;
}

function saveDrawing() {
  saveCanvas('myDrawing', 'png');
}

function setCustomColor() {
  const hexColor = document.getElementById('hexColor').value;
  if (isValidHex(hexColor)) {
    colorSelected = hexColor;
  } else {
    alert('Please enter a valid hex color code!');
  }
}

function isValidHex(hexColor) {
  return /^#[0-9A-F]{6}$/i.test(hexColor);
}
